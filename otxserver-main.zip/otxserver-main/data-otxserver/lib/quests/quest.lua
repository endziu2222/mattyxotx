dofile(DATA_DIRECTORY .. '/lib/quests/killing_in_the_name_of.lua')
