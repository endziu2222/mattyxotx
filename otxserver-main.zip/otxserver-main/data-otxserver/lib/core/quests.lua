if not Quests then
	Quests = {
		--
	}
end
