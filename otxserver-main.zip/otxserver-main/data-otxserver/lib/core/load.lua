dofile(DATA_DIRECTORY .. '/lib/core/storages.lua')
dofile(DATA_DIRECTORY .. '/lib/core/storagesCustom.lua')
dofile(DATA_DIRECTORY .. '/lib/core/quests.lua')
